# Métricas e fórmulas

Toda métrica deve informar período, fuso, moeda, filtros, fonte e versão da regra.

## Aquisição

- **CTR:** cliques ÷ impressões.
- **CPC:** investimento ÷ cliques.
- **CPL:** investimento ÷ leads válidos.
- **CPA:** investimento ÷ compradores/conversões definidos.
- **ROAS bruto:** receita bruta atribuída ÷ investimento.
- **ROAS líquido:** receita líquida atribuída ÷ investimento.

## Conversão

- **Conversão de página:** conversões ÷ visitantes elegíveis.
- **Conversão de checkout:** compras aprovadas ÷ checkouts iniciados.
- **Conversão do webinar:** compradores elegíveis ÷ participantes elegíveis.
- **Conversão da VSL:** compradores elegíveis ÷ espectadores elegíveis.

Denominadores precisam ser exibidos e deduplicados conforme o objetivo da análise.

## Receita

- **Receita bruta:** pagamentos aprovados antes de deduções.
- **Receita líquida:** receita bruta menos reembolsos, chargebacks e deduções definidas.
- **Ticket médio:** receita ÷ pedidos aprovados.
- **Receita por lead:** receita atribuída ÷ leads.
- **Receita por visitante:** receita atribuída ÷ visitantes.

## LTV

- **LTV bruto em N dias:** soma de receitas brutas da pessoa até N dias do marco.
- **LTV líquido em N dias:** soma líquida no mesmo período.

O marco pode ser primeiro lead, primeira compra ou aquisição; a tela deve informá-lo.

## Ascensão

- **Taxa de ascensão:** pessoas que compraram o produto destino ÷ compradores elegíveis do produto origem.
- **Tempo para ascensão:** intervalo entre as compras de origem e destino.
- **Receita de ascensão:** receita posterior ligada à coorte de origem.

## Atribuição

- **Conversão direta:** conversão com crédito principal no modelo selecionado.
- **Conversão assistida:** conversão com participação, mas sem crédito principal.
- **Receita atribuída:** soma dos créditos do modelo; não deve exceder a receita elegível.

## Criativos

Um criativo vencedor exige:

- Objetivo definido.
- Volume mínimo.
- Janela suficiente.
- Métrica primária.
- Guardrails de qualidade, como reembolso e LTV.

Fadiga será uma classificação composta e versionada, não uma fórmula fixa nesta fase.

## Dados

- Cobertura de identidade.
- Cobertura de UTM.
- Latência de ingestão.
- Divergência de receita.
- Taxa de falha/reprocessamento.

## Pendências

- Definir filtros de bots.
- Definir tratamento de impostos, taxas e comissões.
- Aprovar janelas padrão.
- Aprovar volumes mínimos de experimentos e criativos.


# Plataforma de Inteligência de Funis e Jornada do Cliente

Sistema próprio para consolidar dados de anúncios, leads, vendas, webinars e comportamento, preservando o histórico e acompanhando a pessoa desde o primeiro contato até compras e ascensões posteriores.

## Diferencial central

O sistema não analisa apenas campanhas ou produtos isolados. Ele mantém uma jornada única por pessoa, mesmo quando ela atravessa funis perpétuos, webinars, lançamentos, low tickets, upsells e mentorias.

## Estado atual

O projeto está na fase de definição do produto e da arquitetura. As primeiras fontes previstas são Meta Ads, Lastlink, Sendflow, Hotwebinar, Datacrazy e formulários próprios. Rebrandly não faz parte do escopo.

## Documentação

- [PRD](docs/PRD.md): visão, escopo e requisitos do produto.
- [Glossário](docs/GLOSSARIO.md): linguagem comum do projeto.
- [Regras de negócio](docs/REGRAS_DE_NEGOCIO.md): regras essenciais e casos especiais.
- [Atribuição e jornada](docs/ATRIBUICAO_E_JORNADA.md): identidade, influência e ascensão.
- [Arquitetura](docs/ARQUITETURA.md): desenho técnico proposto.
- [Modelo de dados](docs/MODELO_DE_DADOS.md): entidades e relacionamentos.
- [Integrações](docs/INTEGRACOES.md): fontes externas e responsabilidades.
- [Eventos e tracking](docs/EVENTOS_E_TRACKING.md): taxonomia de eventos.
- [Métricas](docs/METRICAS.md): definições e fórmulas.
- [Teste A/B](docs/TESTE_AB.md): links inteligentes e experimentação.
- [IA e automações](docs/IA_E_AUTOMACOES.md): análise e operação segura.
- [UX e design system](docs/UX_E_DESIGN_SYSTEM.md): navegação e padrões visuais.
- [Roadmap](docs/ROADMAP.md): fases de entrega.
- [Decisões](docs/DECISOES.md): registro das escolhas relevantes.
- [Contexto para IA](docs/CONTEXTO_PARA_IA.md): resumo para iniciar outra conversa ou agente.

## Princípios

1. Histórico próprio e permanente.
2. Identidade única do cliente.
3. Métricas explicáveis e reproduzíveis.
4. IA com evidências, limites e auditoria.
5. Integrações idempotentes e observáveis.
6. Interface simples para usuários não técnicos.


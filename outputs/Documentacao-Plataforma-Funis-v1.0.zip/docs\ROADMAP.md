# Roadmap

Status: proposta inicial. Prioridades podem mudar após validar payloads e necessidades operacionais.

## Fase 0 — Fundação e descoberta

- [x] Visão inicial e documentação.
- [ ] Validar payloads reais da Lastlink.
- [ ] Mapear APIs/webhooks das demais fontes.
- [ ] Aprovar regras de identidade e atribuição.
- [ ] Criar wireframes e design system.
- [ ] Montar repositório, ambientes e qualidade.

## Fase 1 — MVP de dados e jornada

- [ ] Organizações, projetos, usuários e permissões.
- [ ] Ingestão idempotente e armazenamento bruto.
- [ ] Lastlink.
- [ ] Meta Ads em modo leitura.
- [ ] Pessoas e resolução inicial de identidade.
- [ ] Pedidos, pagamentos e reembolsos.
- [ ] Touchpoints e UTMs.
- [ ] Jornada individual e ascensão.
- [ ] Dashboard executivo e de campanhas.
- [ ] Saúde das integrações.

## Fase 2 — Funis e criativos

- [ ] Funis perpétuos.
- [ ] Lançamentos.
- [ ] Jornada híbrida.
- [ ] Sendflow.
- [ ] Hotwebinar.
- [ ] VSL/tracking próprio.
- [ ] Biblioteca e backup de criativos.
- [ ] Análise e transcrição por IA.
- [ ] Debriefing.

## Fase 3 — Qualificação e experimentação

- [ ] Pesquisa de persona.
- [ ] Lead scoring explicável.
- [ ] Segmentos.
- [ ] Domínios personalizados.
- [ ] Links inteligentes.
- [ ] Testes A/B.
- [ ] Avaliação por LTV.
- [ ] Reports e alertas automáticos.

## Fase 4 — Inteligência e operação

- [ ] Assistente conectado à camada de métricas.
- [ ] Detecção de anomalias.
- [ ] Simulação de orçamento.
- [ ] Recomendações de campanhas.
- [ ] Aprovação de ações.
- [ ] Pausa e alteração de orçamento.
- [ ] Criação assistida de anúncios.
- [ ] Políticas limitadas de automação.

## Critério para avançar

Uma fase não deve avançar por aparência de completude. Entradas precisam ser reconciliadas, métricas reproduzíveis e falhas observáveis.


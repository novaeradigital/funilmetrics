# Arquitetura proposta

## Visão geral

```text
Meta Ads / Lastlink / Sendflow / Hotwebinar / Datacrazy / Formulários
                              ↓
                 Webhooks e sincronizadores
                              ↓
                  Fila e processamento idempotente
                              ↓
            Dados brutos → normalização → identidade
                              ↓
                 PostgreSQL / Supabase + mídia
                              ↓
             API de aplicação e camada de métricas
                              ↓
           Next.js / dashboards / relatórios / IA
                              ↓
           Aprovação e execução futura de ações
```

## Stack inicial

- TypeScript.
- Next.js e React no frontend.
- Backend TypeScript modular.
- PostgreSQL gerenciado pelo Supabase.
- Drizzle ORM e migrações versionadas.
- Railway para aplicações e workers.
- Armazenamento de objetos para criativos e exportações.
- Fila para processamento assíncrono.

## Organização recomendada

Monorepo:

```text
apps/
  web/
  api/
  worker/
packages/
  database/
  domain/
  integrations/
  metrics/
  ui/
  config/
```

No início, API e web podem compartilhar implantação se isso reduzir complexidade, mas ingestão e tarefas demoradas devem rodar em worker.

## Camadas

1. Ingestão: recebe e autentica.
2. Raw store: preserva o payload.
3. Normalização: converte fontes distintas para contratos internos.
4. Identidade: liga identificadores à pessoa.
5. Domínio: aplica regras de pedidos, funis e jornada.
6. Métricas: cálculos consistentes e versionados.
7. Aplicação: dashboards, filtros e permissões.
8. IA: acessa métricas governadas, não o banco livremente.
9. Ações: executa comandos externos com guardrails.

## Multiempresa e permissões

- Organização contém projetos.
- Dados são isolados por organização.
- Perfis iniciais: proprietário, administrador, editor, analista e visualizador.
- Acesso de cliente pode ser limitado a projetos e dashboards.

## Confiabilidade

- Idempotência e reprocessamento.
- Dead-letter/quarentena.
- Backoff e limites de API.
- Checkpoints de sincronização.
- Monitoramento de atraso e falhas.
- Backups e testes de restauração.
- Logs sem exposição de segredos ou dados desnecessários.

## Segurança

- Segredos fora do código.
- Credenciais criptografadas.
- Menor privilégio nas integrações.
- Controle de acesso por organização/projeto.
- Auditoria de login, exportação e ações críticas.
- Política de retenção e atendimento à LGPD.

## Escala

O volume informado de 8 mil vendas/mês é confortável para PostgreSQL, desde que visitas e eventos sejam modelados e indexados corretamente. A escala deve considerar principalmente eventos de página e anúncios, que podem superar vendas em várias ordens de magnitude.

## Decisões pendentes

- Redis/serviço de fila definitivo.
- Armazenamento de mídia.
- Provedor de WhatsApp.
- Frequência e retenção por categoria de dado.
- Estratégia de warehouse quando o volume justificar.


# Eventos e tracking

## Envelope comum

Todo evento normalizado deve possuir:

- `event_id`
- `event_name`
- `occurred_at`
- `received_at`
- `source`
- `organization_id`
- `project_id`
- `person_id` quando conhecido
- `anonymous_id` quando aplicável
- `session_id` quando aplicável
- referências externas
- contexto de URL, UTM e dispositivo quando disponível
- `schema_version`

## Eventos iniciais

### Navegação e lead

- `page_viewed`
- `form_started`
- `form_submitted`
- `lead_created`
- `identity_identified`
- `cta_clicked`
- `checkout_started`

### VSL

- `vsl_started`
- `vsl_progressed`
- `vsl_pitch_reached`
- `vsl_cta_shown`
- `vsl_cta_clicked`
- `vsl_completed`

Progresso deve conter segundos e percentual, evitando excesso de eventos redundantes.

### Webinar

- `webinar_registered`
- `webinar_joined`
- `webinar_left`
- `webinar_offer_viewed`
- `webinar_cta_clicked`
- `webinar_completed`

### Comunicação

- `message_sent`
- `message_delivered`
- `message_read`
- `message_clicked`
- `message_replied`

### Comercial

- `order_created`
- `payment_pending`
- `payment_approved`
- `payment_refused`
- `payment_refunded`
- `payment_chargeback`
- `subscription_started`
- `subscription_renewed`
- `subscription_cancelled`
- `product_ascended`

### Anúncios

- `ad_metrics_snapshot`
- `campaign_status_changed`
- `budget_changed`
- `creative_detected`

### Experimentos

- `experiment_assigned`
- `variant_exposed`
- `experiment_converted`

## Versionamento

Alterações incompatíveis aumentam `schema_version`. Consumidores devem aceitar reprocessamento. Exemplos reais ficam em `docs/payloads/<fonte>/`, sempre com dados pessoais removidos.


# IA e automações

## Princípio

A IA interpreta dados governados e fornece evidências. Ela não deve executar SQL irrestrito nem alterar campanhas sem política explícita.

## Capacidades

- Responder perguntas sobre campanhas, jornada, produtos e LTV.
- Encontrar anomalias e mudanças relevantes.
- Explicar criativos e padrões vencedores.
- Gerar debriefing de lançamento.
- Produzir relatórios diários e semanais.
- Recomendar pausa, orçamento e novos testes.
- Produzir briefing e variações de criativos.

## Estrutura de uma resposta

- Conclusão.
- Período e filtros.
- Métricas usadas.
- Evidências e links para as telas.
- Hipóteses separadas de fatos.
- Confiança e limitações.
- Ação recomendada.

## Níveis de autonomia

1. Observação.
2. Recomendação.
3. Preparação de ação.
4. Execução após aprovação.
5. Automação limitada por política.

O nível 5 não faz parte do MVP.

## Guardrails

- Amostra mínima.
- Dados recentes e integrações saudáveis.
- Limite monetário e percentual.
- Máximo de alterações por período.
- Aprovação para ações importantes.
- Lista de contas/campanhas permitidas.
- Horário e janela de observação.
- Auditoria completa.
- Mecanismo de interrupção.

## Auditoria

Registrar:

- Modelo e versão.
- Prompt/instrução relevante.
- Dados e métricas consultados.
- Recomendação.
- Aprovação ou rejeição.
- Estado antes/depois.
- Resposta da plataforma externa.

## Privacidade

- Minimizar dados pessoais enviados a modelos.
- Redigir/mascarar campos quando possível.
- Controlar retenção.
- Separar dados entre organizações.


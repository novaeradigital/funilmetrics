# Modelo de dados conceitual

## Organização

- `organizations`
- `projects`
- `users`
- `memberships`
- `roles`
- `audit_logs`

## Identidade

- `people`: pessoa canônica.
- `identities`: e-mail, telefone, cookie, click ID e IDs externos.
- `identity_links`: evidência e confiança da ligação.
- `merge_history`: fusões e reversões.
- `sessions`: sequência técnica de navegação.

## Marketing

- `traffic_sources`
- `ad_accounts`
- `campaigns`
- `ad_sets`
- `ads`
- `creatives`
- `creative_assets`
- `creative_analyses`
- `utm_touchpoints`

Criativo é separado de anúncio para consolidar uma peça reutilizada em vários anúncios.

## Funis

- `funnels`
- `funnel_versions`
- `funnel_steps`
- `funnel_entries`
- `step_events`
- `launches`
- `webinars`
- `webinar_sessions`
- `webinar_participations`

## Produtos e receita

- `products`
- `offers`
- `orders`
- `order_items`
- `transactions`
- `payment_events`
- `refunds`
- `ascensions`

Pedido não é sinônimo de pagamento. Mudanças financeiras são eventos.

## Comportamento

- `events`: contrato normalizado.
- `raw_events`: payload original, hash, fonte e processamento.
- `event_links`: relações do evento com pessoa, sessão, campanha, funil e teste.

## Atribuição

- `touchpoints`
- `conversions`
- `attribution_models`
- `attribution_runs`
- `attribution_credits`

Os créditos são resultados recalculáveis e não substituem os eventos.

## Experimentação

- `domains`
- `smart_links`
- `experiments`
- `variants`
- `allocations`
- `exposures`
- `experiment_conversions`

## Lead scoring e persona

- `surveys`
- `questions`
- `survey_responses`
- `score_models`
- `score_factors`
- `score_results`
- `segments`

## Integrações

- `connections`
- `webhook_endpoints`
- `sync_jobs`
- `sync_checkpoints`
- `processing_failures`
- `data_quality_issues`

## IA e ações

- `ai_conversations`
- `ai_insights`
- `recommendations`
- `action_policies`
- `action_requests`
- `action_approvals`
- `action_executions`

## Regras de modelagem

- Chaves internas não dependem de IDs de fornecedores.
- IDs externos são únicos por fonte e escopo.
- Timestamps guardados em UTC, exibidos no fuso do projeto.
- Valores monetários guardados em unidade mínima e com moeda.
- Dados brutos são imutáveis.
- Entidades mutáveis possuem histórico quando afetam métricas ou auditoria.
- Toda tabela de negócio inclui organização/projeto direta ou indiretamente.


# Contexto resumido para outra IA

## O projeto

Estamos criando uma plataforma de inteligência de marketing e vendas para infoprodutos. Ela consolida anúncios, leads, páginas, mensagens, webinars e pagamentos. O diferencial central é acompanhar uma pessoa por toda a jornada, inclusive quando ela atravessa funis diferentes e compra produtos posteriores.

## Exemplo essencial

```text
Lead entra pelo Criativo X
→ compra low ticket no perpétuo
→ recebe mensagens
→ participa de webinar ao vivo
→ compra Produto Y
→ entra em mentoria
```

O sistema precisa preservar a origem inicial, registrar influências intermediárias, atribuir cada venda e calcular o LTV acumulado.

## Conceitos obrigatórios

- Pessoa possui jornada única.
- Funil, campanha, lançamento e pessoa são conceitos separados.
- Jornada híbrida atravessa múltiplos modelos de funil.
- Conversão direta e assistida aparecem separadamente.
- Histórico fica salvo mesmo se uma conta de anúncio cair.
- Métricas e IA devem ser explicáveis.

## Fontes iniciais

- Lastlink: vendas, produtos, pagamentos e UTMs.
- Meta Ads: campanhas, anúncios, criativos e métricas.
- Sendflow: comunicação.
- Hotwebinar: webinar.
- Datacrazy: escopo a validar.
- Formulários próprios.

Rebrandly não faz parte do projeto.

## Módulos

- Dashboards executivo, campanhas, perpétuo, lançamento e híbrido.
- Pessoas, jornadas e ascensão.
- Biblioteca de criativos com mídia e análise por IA.
- Testes A/B por links inteligentes e domínios personalizados.
- Lead scoring e pesquisa de persona.
- VSL e webinar.
- Relatórios e alertas.
- Assistente para conversar com dados.
- Futuras ações em anúncios com aprovação e auditoria.

## Tecnologia proposta

- TypeScript.
- Next.js/React.
- Backend TypeScript modular.
- Supabase/PostgreSQL.
- Drizzle ORM.
- Railway inicialmente.
- Workers e filas para tarefas assíncronas.

## Estado

Estamos em descoberta/documentação. Antes de implementar regras definitivas, validar payloads reais, principalmente Lastlink, e aprovar janelas de atribuição, identidade e fórmulas.

## Como trabalhar

Leia o `README.md`, o `AGENTS.md` e os documentos em `docs/`. Não invente regras ausentes: marque pressupostos e registre decisões relevantes. Não trate dashboards isolados como fonte da verdade; a fonte são eventos normalizados, identidade e regras versionadas.


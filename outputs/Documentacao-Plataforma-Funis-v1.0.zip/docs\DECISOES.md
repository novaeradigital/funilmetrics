# Registro de decisões

## D-001 — TypeScript como linguagem principal

Data: 23/07/2026  
Status: aceita

Usar TypeScript no frontend e backend para compartilhar contratos, reduzir troca de contexto e manter uma base coerente.

## D-002 — Next.js/React para interface

Data: 23/07/2026  
Status: aceita

Next.js é o framework da aplicação web; React é a biblioteca de interface utilizada por ele.

## D-003 — Supabase/PostgreSQL

Data: 23/07/2026  
Status: aceita

Usar PostgreSQL gerenciado pelo Supabase como banco principal. Dados relacionais e históricos da jornada se beneficiam do modelo relacional.

## D-004 — Drizzle ORM

Data: 23/07/2026  
Status: proposta aceita

Usar Drizzle para schema, consultas tipadas e migrações, mantendo SQL e modelo de dados compreensíveis.

## D-005 — Railway inicialmente

Data: 23/07/2026  
Status: aceita para início

Hospedar aplicação e workers inicialmente no Railway. Reavaliar por custo, confiabilidade e escala observada, sem acoplamento desnecessário.

## D-006 — Jornada híbrida como conceito central

Data: 23/07/2026  
Status: aceita

Pessoas têm uma jornada única e podem atravessar perpétuo, webinar, lançamento e outros funis. Classificamos funis e campanhas, não a pessoa.

## D-007 — Histórico próprio

Data: 23/07/2026  
Status: aceita

Persistir dados de anúncios, criativos e métricas para evitar perda histórica quando contas forem bloqueadas ou conexões removidas.

## D-008 — Teste A/B por link inteligente

Data: 23/07/2026  
Status: aceita

Começar com split por link e domínios personalizados. Script de página e editor visual ficam para etapa posterior.

## D-009 — Rebrandly fora do escopo

Data: 23/07/2026  
Status: aceita

As UTMs já estão disponíveis na Lastlink; o projeto não dependerá do Rebrandly.

## D-010 — Codex para design e implementação

Data: 23/07/2026  
Status: aceita

Criar o design system e as telas diretamente no projeto. Ferramentas externas de prototipação podem servir de referência, mas não serão a base técnica.


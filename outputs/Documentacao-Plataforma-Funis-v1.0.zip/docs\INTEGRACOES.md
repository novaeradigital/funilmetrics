# Catálogo de integrações

## Padrão obrigatório

Cada integração deve documentar:

- Autenticação e permissões.
- Webhooks disponíveis.
- Sincronização histórica e incremental.
- IDs externos.
- Payloads reais.
- Mapeamento para eventos internos.
- Idempotência.
- Rate limits e retentativas.
- Reconciliação.
- Última sincronização e saúde.

## Lastlink

Objetivo: pedidos, compradores, produtos, pagamentos, reembolsos e UTMs.

Decisões:

- Rebrandly está fora do projeto.
- As UTMs já ficam gravadas na Lastlink e devem ser aproveitadas.
- Logs/payloads reais serão a referência do contrato.
- Guardar payload bruto antes de normalizar.

Validar:

- Eventos disponíveis e diferenças de payload.
- IDs de pedido, transação, produto e comprador.
- Estados de pagamento.
- Campos UTM e click IDs.
- Order bump, upsell, assinatura, reembolso e chargeback.

## Meta Ads

Objetivo: contas, campanhas, conjuntos, anúncios, criativos e métricas históricas.

Inicialmente:

- Leitura e arquivamento.
- Sincronização incremental diária e intradiária.
- Cópia de metadados e mídia permitida.

Futuramente:

- Criar, pausar e alterar orçamento com aprovação.

## Sendflow

Objetivo: mensagens, campanhas, listas, entregas, cliques, respostas e possíveis conversões intermediárias.

Validar:

- Webhooks e IDs de contato.
- Telefone normalizado.
- Campanhas e sequências.
- Status de entrega e interação.

## Hotwebinar

Objetivo: inscrições, presença, entrada/saída, duração, interações e sessões.

Validar:

- Eventos ao vivo versus gravação.
- Identidade disponível.
- Métricas de retenção e oferta.
- Relação entre webinar recorrente e lançamento.

## Datacrazy

Objetivo ainda precisa ser detalhado com payloads e fluxo real.

## Formulários próprios

Objetivo: captura de lead, pesquisa de persona e eventos comportamentais.

Devem enviar:

- Identificador do projeto.
- Página e URL.
- UTMs.
- Identificador do visitante.
- Campos do formulário.
- Consentimento quando aplicável.
- Timestamp e chave idempotente.

## Próximas integrações possíveis

- Google Ads.
- Outros gateways.
- Plataformas de e-mail/CRM.
- WhatsApp para relatórios.

Só entram no roadmap após as fontes iniciais estarem confiáveis.


# UX e design system

## Objetivo

Transformar dados complexos em decisões claras para usuários não técnicos.

## Navegação proposta

- Visão geral
- Campanhas
- Criativos
- Funis
  - Perpétuo
  - Lançamentos
  - Jornada híbrida
- Pessoas e jornadas
- Produtos e ascensão
- Experimentos
- Relatórios e alertas
- Assistente de IA
- Integrações
- Qualidade dos dados
- Configurações

## Padrões

- Cards com comparação e contexto, não números isolados.
- Filtros globais de projeto, período, produto e origem.
- Tabelas com colunas configuráveis e exportação controlada.
- Gráficos com definição da métrica acessível.
- Linha do tempo para a jornada individual.
- Funil para perdas entre etapas.
- Caminhos/Sankey apenas quando facilitar análise de ascensão.

## Estados obrigatórios

- Carregando.
- Sem dados.
- Sem permissão.
- Integração atrasada.
- Erro recuperável.
- Dado parcial.
- Filtro sem resultado.

## Biblioteca de criativos

Card deve exibir mídia, nome, status, tags, investimento, resultado e fadiga. A página detalhada apresenta transcrição, estrutura, histórico, públicos, campanhas, LTV e análise de IA.

## Acessibilidade e responsividade

- Contraste suficiente.
- Navegação por teclado.
- Texto alternativo.
- Não depender apenas de cor.
- Tabelas adaptadas ao celular.
- Informações críticas legíveis sem hover.

## Processo de design

1. Mapa de telas.
2. Wireframes.
3. Três direções visuais comparáveis.
4. Escolha da direção.
5. Tokens e componentes.
6. Protótipo com dados realistas.
7. Validação responsiva.

